const https = require('https');

const request = require('request');

exports.handler = async (event, context) => {
    //console.log('Received event:', JSON.stringify(event, null, 2));

    // Get the object from the event and show its content type
    const bucket = event.Records[0].s3.bucket.name;
    const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
    const params = {
        size: event.Records[0].s3.object.size,
        Bucket: bucket,
        Key: key,
    };
    
    const videoLink = `https://${event.Records[0].s3.bucket.name}.${event.Records[0].awsRegion}.amazonaws.com/${event.Records[0].s3.object.key}`;
    const bodyToUpload = {
        upload: {
        approach: 'pull',
        size: event.Records[0].s3.object.size,
        link: videoLink
        },
        file_name: event.Records[0].s3.object.key
    };
    // 
    console.log("<<<<<===== UPLOADING BODY HERE =====>>>>>");
    console.log(bodyToUpload);
    
    // const options = {
    //     protocol: 'https:',
    //     // hostname: 'postman-echo.com',
    //     // port: 443,
    //     method: 'POST',
    //     path: 'https://api.vimeo.com/me/videos',
    //     headers: {
    //         'Content-Type': 'application/json',
    //         Authorization: 'Basic 5d0c1cbeb46cae47dfb25fbee1a0216c'
    //     }
    // };
    
    
    // return new Promise((resolve, reject) => {
    //     const req = https.request(options, (res) => {
    //         let body = '';
    //         res.on('data', (chunk) => {
    //             body += chunk;
    //         });

    //         res.on('end', () => {
    //             console.log(body)
    //             if (res.statusCode / 2 === 100 ) {
    //                 console.log('success')
    //                 resolve('Success');
    //             }
    //             else {
    //                 console.log('failed')
    //                 resolve('Failure');
    //             }
    //         });
    //         res.on('error', () => {
    //             console.log('error');
    //             reject(Error('HTTP call failed'));
    //         });
    //     });
    //     // The below 2 lines are most important part of the whole snippet.
    //     req.write(JSON.stringify(bodyToUpload));
    //     req.end();
    // });
    
    
    request.post(
       `https://api.vimeo.com/me/videos`,
       bodyToUpload,
       (uploadError, response, vimeoBody) => {
         if (uploadError) {
           console.log(uploadError);
         } else {
           vimeoBody = JSON.parse(vimeoBody);
           // console.log(vimeoBody);

           // extracting videoId from response link
           const vimeoVideoId = vimeoBody.link
             .split('/')
             .filter((number) => {
               if (!isNaN(number)) {
                 return number;
               }
             })[0];

           console.log(vimeoVideoId);
         }
       }
     ).auth(null, null, true, process.env.VIMEO_ACCESS_TOKEN);

};
